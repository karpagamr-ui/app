const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/menu', (req, res) => {
  fs.readFile(path.join(__dirname, 'menu.json'), 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading menu');
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.post('/order', (req, res) => {
  const order = req.body;
  console.log('Order received:', order);
  // In a real app, save to database
  res.json({ message: 'Order placed successfully', orderId: Date.now() });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});